function gallary(){
    var elem = document.querySelector("#captions");
    var gradient = "linear-gradient(rgba(0,0,0,0.0),rgba(0,0,0,0.5)),";
    var images = [
        "african-university-students-group-sitting-outdoors-52812706.jpg",
        "jacqueline-kelly-PeUJyoylfe4-unsplash.jpg",
       "african-university-students-group-sitting-classroom-39109743.jpg",
       "vlcsnap-2021-02-07-22h06m16s953.png"
    ];
    
    var id = setInterval(changeImage,5000);

    function changeImage(){

         var point = Math.floor(Math.random() *(4-0))+0;
         var imageSrc = "../assets/"+images[point];
         elem.style.backgroundImage = gradient +'url('+ imageSrc+ ')';
      
    }

}

function show_loader(wrapper_selector){
    document.querySelector(wrapper_selector).style.display = "block";
}

function hide_loader(wrapper_selector){
    setTimeout(() => {
        document.querySelector(wrapper_selector).style.display = "none";
    }, 2000);
}