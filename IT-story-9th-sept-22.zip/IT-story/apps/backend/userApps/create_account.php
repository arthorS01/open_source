<div id="confirmation">
<h2>Account created successfully</h2>
<a href="../public/index.php" class="button">Log-in</a>

</div>
    
    <img src="../assets/user (1).png" height="70" width="70">


    <section id="change" class="animate">
        <h2>Select your account type</h2>

        <button class="button" onclick="swapID('change','student_account')">Student</button>
        <button class="button" onclick="swapID('change','supervisor_account')">Supervisor</button>

    </section>

    <section id="hidden">

        <div id="student_account">
            <button class="back_button" onclick="bring_page('#form','../apps/backend/userApps/create_account.php')">Back</button>
            <h2>Create your student account</h2>
            <div>
                <p class="error" ></p>
                <form class="animate"> 

                <input type="text" name = "username" placeholder="Create your username" onkeyup="hideError('.error')">
                <br>
                <input type="password" name="password" placeholder="Create your password" onkeyup="hideError('.error')">
                <br>
                <input type="password" name="confirm_passw" placeholder="Confirm your password" onkeyup="hideError('.error')">
                <br>
                <input type="text" name="matNo" placeholder="What is your MAT number" onkeyup="hideError('.error')">
                <br>
                <input type="email" name="email" placeholder="Email address" onkeyup="hideError('.error')">
                <br>
                <input type="submit" name="submit_button" value="Done" onclick="submitForm('../apps/backend/userApps/process_student_account.php',showResponse)">
 
            </form>


            
        </div>


        </div>

     

            <div id="supervisor_account">

                <button class="back_button" onclick="bring_page('#form','../apps/backend/userApps/create_account.php')">Back</button>
                <h2>Create your supervisor account</h2>
                <div>
                    <p class="error"></p>

                    <form class="animate"> 
    
                    <input type="text" name = "username" placeholder="Create your username" onkeyup="hideError('.error')">
                    <br>
                    <input type="password" name="password" placeholder="Create your password" onkeyup="hideError('.error')">
                    <br>
                    <input type="password" name="confirm_passw" placeholder="Confirm your password" onkeyup="hideError('.error')">
                    <br>
                    <input type="email" name="email" placeholder="Email address" onkeyup="hideError('.error')">
                    <br>
                    <input type="submit" name="submit_button" value="Done" onclick="submitForm('../apps/backend/userApps/process_supervisor_account.php',showResponse)">
     
                </form>


               

            </div>
    
    
        
    </section>
