<?php

require_once "../classes/User.php";
require_once "../classes/Validation.php";




if(isset($_POST["outgoing_email"])){

  try{ 
       $incoming_email = $valid->sanitize($_POST["incoming_email"]);
        $outgoing_email = $valid->sanitize($_POST["outgoing_email"]);
        $message        = $valid->sanitize($_POST["message"]);


        $sent = $user->sendMessage($message,$incoming_email,$outgoing_email);

        if(!$sent){
            
            echo false;

        }else{
            echo JSON_encode($message);
        }

}catch(EXCEPTION $e){
    echo"error";
}

}


