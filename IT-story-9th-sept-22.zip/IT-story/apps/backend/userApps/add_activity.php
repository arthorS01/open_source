<?php

    session_start();

    require_once "../classes/Activity.php";
    require_once "../classes/Validation.php";
    require_once "../classes/User.php";


   if(isset($_POST["activity"])){

    $activity = $valid->sanitize($_POST["activity"]);
    $picture = $valid->sanitize($_POST["picture"]);

    $success = $user->add_activity($_SESSION["email"],$activity,$picture);

    if($success = true){
        echo "activity was addedd sucessfully";
    }

   }

