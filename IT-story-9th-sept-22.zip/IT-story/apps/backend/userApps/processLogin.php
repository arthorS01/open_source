<?php
session_start();

include "../classes/Validation.php";
include "../classes/User.php";


 $name = $valid->sanitize($_POST["username"]);
 $password = $valid->sanitize($_POST["password"]);

 $response = [];
 $response["user_exists"] = false;
 $response["text"] = "invalid username or password";
 $response["url"] = null;


 if($user->checkUser($name,$password)){
    
       $_SESSION["name"] = $name;
       $_SESSION["account"] = $user->get_data($name,$password,"account");
       $_SESSION["email"] = $user->get_data($name,$password,"email");

       $response["user_exists"]  = true;
       $response["text"]  = "user exists";
       
       switch($_SESSION["account"]){
              case "student":
                     $response["url"] = "../apps/backend/userApps/student_book.php";
                     break;
              case "supervisor":
                     $response["url"] = "../apps/backend/userApps/supervisor_dashboard.php";
                     break;
              default:
                     $response["user_exist"] = false;
                     break;
       }
      
       }



echo JSON_encode($response);
         
 