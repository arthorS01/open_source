<?php

    session_start();

    require_once "../classes/Validation.php";
    require_once "../classes/User.php";
    
    $setting = [];
    
 if(isset($_POST["first_name"])){

    $setting["first_name"] = $valid->sanitize( $_POST["first_name"] );
    $setting["last_name"]  = $valid->sanitize($_POST["last_name"]);
    $setting["company_name"] = $valid->sanitize($_POST["company_name"]);
    $setting["company_location"] = $valid->sanitize($_POST["company_location"]);
    $setting["employer_name"]  = $valid->sanitize($_POST["employer_name"]);

  
 
    //update Settings
    if($user->set($_SESSION["email"],$setting,1)){

        return true;
    }

 }


 if(isset($_POST["theme_color"])){

    $setting["color_theme"] = $valid->sanitize($_POST["color"]);
    $setting["dark_theme"]  = $valid->sanitize($_POST["dark_theme"]);

    
    if($user->set($_SESSION["email"],$setting,$type)){

        echo" set successful";
    }
 }