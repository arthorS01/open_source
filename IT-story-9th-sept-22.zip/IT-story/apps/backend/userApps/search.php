<?php

    require_once "../classes/Validation.php";
    require_once "../classes/User.php";


    $search_key = $_REQUEST["r"];
    $output = '';
    $search_result = $user->search($search_key);
  

    if($search_result){

      
        foreach($search_result as $result){

            $output .= '<div id="search_data"> 
            
                    <div class="user_details">
                        
                        <div class="user_img">
                           
                        </div>
                        
                        <div class="text">

                            <p>'.$result["username"].'</p>
                            <p>'.$result["email"].'</p>
                            <p>name of school</p>

                        </div>
                        
                    </div>';

            if($result["account"] == "student"){

                $output.=' <div class="action">
                                <i class="icofont-book-alt"></i>
                                <button>View story</button>
                                </div>
                         </div>';
            }else{

                $output.='<div class="action">
                            <i class="icofont-user-alt-4"></i>
                                <button>contact admin</button>
                            </div> 
                        </div>';
            }

        }
        echo JSON_encode($output);

    }else{
        echo JSON_encode("not found");
    }