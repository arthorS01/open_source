<?php


$theme_background_color = "#ff6699 ";
$theme_text_color = "#330011";

$css = '
#new_activity form input[type="submit"]{

    background-color:rgb(60, 60, 219);
    color:white;
}

#log_out:hover{
    
    color:darkblue;
    font-weight: bold;
    background-color:lightblue;
    transition: 0.3s ease-in all;
}

.incoming_msg{

    background-color:rgb(40, 62, 184);
   color:white;
}

.outgoing_msg{
    background-color:white;
}

#new_activity form textarea{
  
    box-shadow: 0px 0px 4px 2px '.$theme_background_color.' ;
    color:white;
}
.theme_color{
   color:'.$theme_text_color.';
}
.theme_color_button{

    background-color:'.$theme_background_color.' !important;
 
 }
 
 #navigation ul li button{

    background-color:'.$theme_background_color.';   
}

#track{
    background-color:'.$theme_background_color.';
}';

$p_file = fopen("../../../UI/user_preference.css","w") or die("unable to open file");
$success = fwrite($p_file,$css);

if($success){
    echo "settings saved";
}
