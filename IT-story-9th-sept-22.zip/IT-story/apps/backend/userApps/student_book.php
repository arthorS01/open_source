<?php

    session_start();

    if(!isset($_SESSION["name"])){
        //redirect
        header("location: ../../../public/index.php");
    }

?>
<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../../UI/student_book.css" rel="stylesheet" type="text/css">
    <link href="../../../assets/icofont/icofont.min.css" rel="stylesheet" >
    <link href="../../../UI/user_preference.css" rel="stylesheet" type="text/css">

    <title>Document</title>
</head>

<body onload="get_activity('activity.php',create_activity_node)">
    

    <section id="interface">
        
        <span id="log_out">log-out</span>

       <?php 
       
            include "../include/settings.php"; 
        
            include "../include/book.php";

            include "../include/chat.php";
       
       ?>

    </section>

</body>

<script src="../libraries/activity.js"></script>
<script src="../libraries/events.js"></script>
</html>

