<?php 

include "../classes/Validation.php";
include "../classes/User.php";

$username     = $valid->sanitize($_POST["username"]);
$password     = $valid->sanitize($_POST["password"]);
$cPassword    = $valid->sanitize($_POST["confirm_passw"]);
$email        = $valid->sanitize($_POST["email"]);

$response["created"] = false;
$response["text"]    = null;
$response["status"]  = true;   
 

if($valid->check_num_string($username)){
    $response["status"] = false; 
    $response["text"]    = "Please your username should not contain numbers";
}
if(!$valid->checkPassword($password)){
    $response["status"] = false;
    $response["text"]    = "Please , make your password stronger";
}
if(!($password === $cPassword)){

        $response["status"] = false;
        $response["text"]   = "Please check the passwords provided"; 
}

if($response["status"] == true){

    $user->setUser($username,$password,$email,null,"supervisor");
    if($user->createUser()){
        $response["created"] = true;
    }else{
        $response["text"] = "Sorry,please try again some other time";
    }
}

//add function for confirming email account



echo JSON_encode($response);

