<?php

    session_start();

    require_once "../classes/Activity.php";

    $activities->set_email($_SESSION["email"]);
    $activities->getDetails();