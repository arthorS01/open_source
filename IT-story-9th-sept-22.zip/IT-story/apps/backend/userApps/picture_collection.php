<?php

    require_once "../classes/Activity.php";


    $regular_pic_dir = "../../../assets/pic_collection";
    

   
    $result = $activities->get_pic_dir($regular_pic_dir);
    

  
   

    echo JSON_encode($result);
    
     
   
    