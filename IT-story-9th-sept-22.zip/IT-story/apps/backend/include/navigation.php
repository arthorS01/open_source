<div id="navigation">

       <ul>

            <li><button onclick="close_box(this,'#settings_container')" class="theme_color"><i class="icofont-ui-settings "></i></button></li>
            <li><button onclick="close_box(this,'#chat_container')" class="theme_color"><i class="icofont-ui-text-chat "></i><span id="message_counter"></span></button></li>
           
           <div id="calander_container">
                <li><button class="theme_color" onclick="close_box(this,'#calander')"><i class="icofont-ui-calendar "></i></button></li>
                
                <?php include"calander.php";  ?>
            </div>

       </ul>
        
       <button id="mobile_menu_bar" class="theme_color_button"><i class="icofont-navigation-menu"></i></button>

    </div>


    <!-- 

         <i class="icofont-ui-settings theme_color" class=" theme_color" onclick="close_box(this,'#settings_container')"></i>
        <i class="icofont-ui-text-chat theme_color" onclick="close_box(this,'#chat_container')"></i>
        <i class="icofont-ui-calendar theme_color"></i>
    -->