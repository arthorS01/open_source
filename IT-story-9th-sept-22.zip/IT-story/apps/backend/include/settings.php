
 <section id="settings_container">

            <p><?php echo $_SESSION["name"]."'s settings";?></p>

            <button type="button" onclick="close_box(this)" class="close_bar">x</button>

            <section class="setting_type">

                <p id="personal_set" class="theme_color_button"> <i class="icofont-ui-user"></i>Personal<button class="icofont-arrow-down"></button></p>
                <p class="error"></p>

                    <div id="details_set_container">

                        <form id="details_set">

                            <div class="set">
    
                                <label for="firstname">First name</label>
                                <input type="text" name="first_name" value="" placeholder="Enter your first name">
    
                            </div>   
    
                            <div class="set">
    
                                <label for="lastname">Last name</label>
                                <input type="text" name="last_name" value="" placeholder="Enter your last name">
                  
                            </div> 

                            <div class="set">

                                <label for="company_name">Company name</label>
                                <input type="text" name="company_name" value="" placeholder="Enter the company's name">

                            </div> 
    
                            <div class="set">
    
                                <label for="company_location">Company location</label>
                                <input type="text" name="company_location" value="" placeholder="Enter the location here">
                                
                            </div> 
    
                            <div class="set">
    
                                <label for="employer_name">Employer's name</label>
                                <input type="text" name="employer_name" value="" placeholder="Enter your employer's name here">
                            
                            </div> 
                        
                            <input type="submit" class="theme_color_button" name="save_settings" value="Save" id="personal_settings_btn" >
                        </form>
                        
                    </div>
                    
                    <div class="loader">


                    </div>

            </section>

            <section class="setting_type">

                <p id="appearance_set" class="theme_color_button" ><i class="icofont-paint"></i>Appearance<button class="icofont-arrow-down"></button></p>

                <p class="error"></p>

                <div id="appearance_set_container">
                   
                    <form id="appearance_settings"> 
                        <div>
                            
                            <div id="color_selector">

                            <?php include "main_theme.php"; ?>
                                <?php include "color_palette.php"; ?>
                             

                            </div>

                            <input type="hidden" id="color_value" name="color_selector" value="">
                        
                        </div>

                        <div>

                            <div id="toggle_container">

                                <span id="circle_btn"></span>

                            </div>
                            <input type="hidden" name="toogle_theme" value="">

                        </div>    
                        <input type="submit" class="theme_color_button" value="save" disabled>


                    </form>

                </div>
            </section>

        </section>