<div id="tools">
        
    <div id="search">
            
        <form>
            <input type="text" name="search-item" id="search_item" placeholder="What would you like to search for ?">

            <button id="search_btn"><i class="icofont-search"></i></button>
            <div id="search_results"></div>
        </form>

       

    </div>

