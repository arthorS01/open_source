
<section id="book" >

    <?php 
    
        include"../include/navigation.php";
        include"../include/search.php"; 
        
    ?>

<section id="activity_container">

    <div class="activity" id="new_activity">

        <button id="add_button" onclick="show_element('#add_button','#add_activity')">+</button>

        <div id="add_activity">

            <p id="date">Today</p>

            <form id="form_acivity">

                <button  class="close" onclick="show_element('#add_activity','#add_button')">x</button>

                <textarea type="text" placeholder="what did you do today?" name="activity" cols="30" rows="5"></textarea>
                <input type="hidden" name="picture" id="picture_name" value="jacqueline-kelly-PeUJyoylfe4-unsplash.jpg">
                <input type="submit" name="add_activity" id="add_new_activity" value="Done">

            </form>

            <section name="picture_section">
            
            <section id="display">

                <div id="sample_display" >
                    <p id="date">date</p>
                    <p class="statement">i learnt how to...</p>

                </div>

                
                <div id="picture_collection"></div>

            </section>
                <div id="choose_pic_text"> <i id="choose_pic"class="icofont-picture"></i><i class="icofont-attachment"></i>
            
                <div id="attachments">
              
                </div> 
            </section>
         </div>
    </div>

</section>

</section>