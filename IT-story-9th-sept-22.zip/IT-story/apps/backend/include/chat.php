
   <section id="chat_container">
           
           <section id="chat">
               <button class="close_bar" onclick="close_box(this)">x</button>

               <div id="user_id">

                   <div class="user_img"></div>

                   <div class="user_details"> 
                       <p><?php echo $_SESSION['name']."'s supervisor"?></p>
                   </div>

              </div>

               <div id="messages" name="messages"></div>
               <div id="form">
                   <form name="chat_form">
                       <input type="text" placeholder="Enter your message" id="chat_message" name="message" value="">
                       <input type="hidden" name="outgoing_email" value=<?php echo '' .$_SESSION["email"] ; ?> >
                       <input type="hidden" name="incoming_email" value="johnokafor@gmail.com" >
                       <button type="submit" class="theme_color theme_color_button" id="post_msg">Send<i class="icofont-telegram"></i></button>
                   </form>
               </div>
           </section>

       </section>