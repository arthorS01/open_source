<div>
    <span>Dark theme<span>
    <div id="main_theme_container">

        <div id="track">

        </div>

        <div id="slider" class="theme_color_button"></div>   
    </div>
    </div>