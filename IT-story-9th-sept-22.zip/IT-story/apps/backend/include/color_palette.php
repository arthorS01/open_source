<div id="pallette_container">

        <span>Theme color</span>

        <div id="pallette">

                <div id="colors">

                        <span style="background-color: #5375e2; " id="c1">

                                <input type="hidden" value="#d3dcf8" name="dark_theme_#5375e2" id="dark_theme_#5375e2" >
                        </span >
                        <span style="background-color: #7791a1;" id="c2">

                                <input type="hidden" value="#e1e7ea" name="dark_theme_#7791a1" id="dark_theme_#7791a1">
                        </span>
                        <span style="background-color:#00cc66;" id="c3">

                                <input type="hidden" value="#ccffe6" name="dark_theme_#f65868" id="dark_theme_#f65868">

                        </span><br>
                        <span style="background-color:#e64d19;" id="c4">

                                <input type="hidden" value="#fadbd1" name="dark_theme_#f3aa92" id="dark_theme_#f3aa92">
                        </span>
                        <span style="background-color: #5c616e;" id="c5">
                        
                                <input type="hidden" value="#e3e5e8" name="dark_theme_#5c616e" id="dark_theme_#5c616e">       

                        </span>
                        <span style="background-color: #9900e6;" id="c6">
                        
                                <input type="hidden" value="#eeccff" name="dark_theme_#cc66ff" id="dark_theme_#cc66ff">

                        </span>
                </div>

                <input type="hidden" value="" name="dark_theme_#5375e2" >
                <div id="preview">

                        <span></span>
                
                </div>
        </div>
</div>