var request = new XMLHttpRequest();
var response = null;
var pic_collection = null;
var pic_collection_urls = null;
var form_endpoint = "../userApps/add_activity.php";
let search = document.querySelector("#search>form>input[type='text']");
let showPic_btn = document.getElementById("choose_pic");
let add_activity = document.querySelector("input[name='add_activity']");
let body_elem = document.querySelector("body");
let pic_endPoint ="../userApps/picture_collection.php";
let pic_url = "../../assets/pic_collection";
let post_msg_btn =  $("#post_msg");

let personal_setButton = $("#personal_set button");
let appearance_setButton = $("#appearance_set button");
let save_settingsButton = $("#personal_settings_btn");
let settings_input      = $$('.set input[type="text"]');
let setting_error       = false;
let setting_colors      = $$("#pallette #colors span");
let default_preview_color  = "blue";
let dark_theme_set          = $("#main_theme_container");

dark_theme_set.addEventListener("click",function(){
    $("body").classList.toggle("dark_theme");
    

});




setting_colors.forEach(function(color){

    color.addEventListener("click",function(){

        let id_b = color.id;
        let color_value = color.style.backgroundColor;
        let preview = $("#preview span");
        preview.style.backgroundColor = color_value;

       
        setColor( id_b,color_value);
    });
});

settings_input.forEach((setting)=>{
   
    setting.addEventListener("keyup",function(){

        let value = setting.value;
    });
});

save_settingsButton.onclick = function(event){

    event.preventDefault();

    let form = save_settingsButton.parentElement;
    form = new FormData(form);

    xhrData(form,null,"../userApps/settings.php","POST");
}
personal_setButton.onclick = function(){

    let state = $("#details_set").style.display;

    if(state == "block"){
        $("#details_set").style.display = "none";
    }else{
        $("#details_set").style.display= "block";
    }

    personal_setButton.classList.toggle("icofont-arrow-up");
}

appearance_setButton.onclick = function(){
 
    let state = $("#appearance_settings").style.display;

    if(state == "block"){
        $("#appearance_settings").style.display = "none";
    }else{
        $("#appearance_settings").style.display= "block";
    }

    appearance_setButton.classList.toggle("icofont-arrow-up");
}

search.addEventListener("keyup",()=>{
    
    document.querySelector("#search_results").style.display = "block";

    request.onreadystatechange = function(){

        if(this.readyState == 4 && this.status ==200){
            document.querySelector("#search_results").innerHTML = JSON.parse(this.responseText);
        }
    };

    request.open("GET","../userApps/search.php?r="+search.value);
    request.send();



    if(!search.value){
        document.querySelector("#search_results").style.display = "none";
    }
});



add_activity.addEventListener("click",(e)=>{
    e.preventDefault();
    
    let activity = document.querySelector("textarea[name='activity']");
    let date = (new Date()).toDateString();

});


showPic_btn.addEventListener("click",function(){

    let pic_collection = document.querySelector("#display");

    if(pic_collection.style.display == "block"){

        pic_collection.style.display = "none";
        document.querySelector("#add_activity form").style.visibility ="visible";
        document.querySelector("#add_activity #date").style.visibility = "visible";

    }else{
        pic_collection.style.display = "block";
        document.querySelector("#add_activity form").style.visibility ="hidden";
        document.querySelector("#add_activity #date").style.visibility = "hidden";

        if(pic_collection_urls == null){

           request.onreadystatechange = function(){
                if(this.readyState == 4 && this.status == 200){
                    pic_collection_urls = this.responseText;
                    pic_collection_urls = JSON.parse(pic_collection_urls);
                 
                  for (const pic in pic_collection_urls) {
                      if (Object.hasOwnProperty.call( pic_collection_urls, pic)) {
                          const picture_name =  pic_collection_urls[pic];

                          //create pic element;
                          let elem = document.getElementById("picture_collection");
                          let  newPic = document.createElement("span");
                          newPic.setAttribute("class","picture");
                          newPic.setAttribute("id",picture_name);
                          newPic.style.backgroundImage = "url('../../../assets/pic_collection/" + picture_name +"')";
                        
                          newPic.addEventListener("mouseover",()=>{

                                let display = document.getElementById("sample_display");
                                display.style.backgroundImage = "linear-gradient(rgba(0,0,0,0.7),rgba(0,0,0,0.1)),url('../../../assets/pic_collection/" + newPic.id+"')";
                                let pic_board = document.getElementById('picture_collection');
                                pic_board.style.opacity = "0.5";
                              
                          });

                          newPic.addEventListener("mouseout",()=>{

                            let display = document.getElementById("sample_display");
                            display.style.backgroundImage = "linear-gradient(rgba(0,0,0,0.7),rgba(0,0,0,0.1)),url('../../../assets/jacqueline-kelly-PeUJyoylfe4-unsplash.jpg')";
                            let pic_board = document.getElementById('picture_collection');
                            pic_board.style.opacity = "1";
                      });

                      newPic.addEventListener("click",()=>{
                        let display = document.getElementById("sample_display");
                        display.style.backgroundImage = "linear-gradient(rgba(0,0,0,0.7),rgba(0,0,0,0.1)),url('../../../assets/pic_collection/" + newPic.id+"')";
                        document.getElementById("picture_name").value =  newPic.id;
                  });
                          elem.appendChild(newPic); 
                      }
                  } 
                }
            };
            request.open("GET",pic_endPoint);
            request.send();   
        }
    }
});

let activity_form = document.getElementById("add_new_activity");

activity_form.addEventListener("click",function(e){
    e.preventDefault();
    
    let formData = activity_form.parentElement;

    if(formData["activity"].value ==''){
         alert("Please you have not entered an activity");
    }else{
        let my_form = new FormData(formData);

        request.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
                //console.log("found file to send to form data to ");
               // console.log(this.responseText);
            }
        };

        request.open("POST",form_endpoint);
        request.send(my_form);
    }
});

post_msg_btn.onclick = function(e){

        e.preventDefault();
        
        let form = post_msg_btn.parentElement;
        let myForm = new FormData(form);
        request.onreadystatechange = function(){

            if(this.readyState == 4 && this.status == 200){
                 if(this.responseText){
                     createChatBalloon("p","class","outgoing_msg",JSON.parse(this.responseText));
                    document.getElementById("chat_message").value = "";
                 }
            }
        }

        request.open("POST","../userApps/post_chat.php");
        request.send(myForm);
};




function createChatBalloon(element,attribute,attr_value,message){

    let newelement = document.createElement(element);
    let chat_area = document.getElementById("messages");
    newelement.setAttribute(attribute,attr_value);
   
    newelement.innerText = message;

    if(attr_value == "outgoing_msg"){

        newelement.classList.add("theme_color");
    }else{
        newelement.classList.add("theme_color_button");
    }
    chat_area.appendChild(newelement);
    
    
   
}

function $(selector){

    return document.querySelector(selector);
}
function $$(selector){

    return document.querySelectorAll(selector);

}

function showError(err_statement,identifier){

    let error_elem = document.querySelector(identifier);
    error_elem.style.display = "block";
    error_elem.innerHTML = err_statement;

}
function xhrData(data,callback,endpoint,request_type){

    let request =  new XMLHttpRequest();
    request.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200){
            console.log(this.responseText);
        }
    };

    
   if(request_type == "POST" ){

       request.open(request_type,endpoint);
       request.send(data);

   }else if(request_type == "GET"){

        request.open(request_type,endpoint+"?data="+data);
        request.send();
    
   }else{
       console.log("invalid request type");
       return false
   }
  

}
function setColor(id_b,val){

   // $$(".theme_color").style.color = val;
   let all_icons = $$(".theme_color");
   all_icons.forEach(function(icon){

    icon.style.color = val;
   
   let background = $( "#"+id_b+ "> input[type='hidden']" ).value;
    icon.style.backgroundColor = background;

   });

   let all_buttons =  $$(".theme_color_button");

    all_buttons.forEach(function(button){

    button.style.backgroundColor = val;

   });

   let track = $("#track");
   let background = $( "#"+id_b+ "> input[type='hidden']" ).value;
   track.style.backgroundColor = background;

  /* let all_nav_btn = $$("#navigation ul li button");

   all_nav_btn.forEach(function(nav_btn){

        nav_btn.style.backgroundColor = val;
        nav_btn.style.color = "white";
   });
   */
}