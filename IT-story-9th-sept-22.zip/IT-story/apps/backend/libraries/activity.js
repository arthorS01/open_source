var request = new XMLHttpRequest();
var response = null;

/*functions peculiar to the page*/

function show_element(selector,selector2,self=this){

    self.addEventListener("click", function(e){
        e.preventDefault();
      
        let elem1 = document.querySelector(selector);
        let elem2 =  document.querySelector(selector2);

        if(elem1.style.display != "none"){

            elem1.style.display = "none";
            elem2.style.display = "block";

    }
    });

}

function get_activity(endpoint,callback=null){

    request.onreadystatechange = function(){

        if(this.readyState == 4 && this.status == 200){
            response = this.responseText;
            //console.log(response);
            if(callback != null){
                callback();
            }
        }
    };

    request.open("GET",endpoint);
    request.send();
}

function create_activity_node(){

  let days = JSON.parse(response);

    days.forEach( day => {
    
        let new_activity = document.getElementById("new_activity");
        let activity_container = document.getElementById("activity_container");
      
        let activity_div = document.createElement("div");
        activity_div.setAttribute("class","activity");
        let activity = document.createElement("p");
        let text =  document.createTextNode(day.activity);
        activity.setAttribute("class","statement");
        activity.appendChild(text);

        let date_of_activity = document.createElement("p");
        date_of_activity.setAttribute("class","date");
        let adate = document.createTextNode(day.date);
        date_of_activity.appendChild(adate);

        activity_div.appendChild(activity);
        activity_div.appendChild(date_of_activity);

       activity_container.appendChild(activity_div);
       activity_container.insertBefore(activity_div,new_activity);
   
       activity_div.style.background = "linear-gradient(rgba(0,0,0,0.7),rgba(0,0,0,0.1)),url('../../../assets/pic_collection/" + day.background_image+"')";

    });
    }

    function close_box(self,element=null){
        if(element == null){
            (self.parentElement).style.visibility = "hidden";
        }else{
            var box = document.querySelector(element);
            if(box.style.visibility == "visible"){
                box.style.visibility = "hidden";
            }else{
                box.style.visibility = "visible";
            }
        }
    }

   