var request = new XMLHttpRequest();
var response = null;
var counter = 0;
var container = null;


function submitForm(endpoint,callback){

    let form = document.querySelector("form");
    
    form.addEventListener("submit",(e)=>{
        e.preventDefault();
        
        //get all the empty feilds
        let input_field = form.getElementsByTagName("input");
        //ensure no empty feild
        if(check_empty_input(input_field,input_field.length)){
            showError("Please fill out all fields",".error");
            return ;
        }

        let form_data = new FormData(form);
     
        ajaxSubmit(endpoint,callback,form_data);

    });
}
function processForm(){
  
    response = JSON.parse(response);
   
    if(response.user_exists == true){
        redirect_page(response.url);  
    }else{
        showError(response.text,".error");
    }
}
function showResponse(){

    console.log(response);
    response = JSON.parse(response);
   if(response.text != null){
        showError(response.text,".error");
    }
    else if(response.created == true ){
        //show confirmation
        //document.getElementById("form").style.filter = "blur(10px)";
        document.getElementById("confirmation").style.display ="block";
    }else{
        showError(response.text,".error");
    }
   
}

function bring_page(container_selector,url){
      
        container = container_selector;
        ajaxSubmit(url,swapPage); 

}
function swapPage(){

    document.querySelector(container).innerHTML = response;

}
function swapID(current_id,new_id){
    
    let oldElem = document.getElementById(current_id);
    let newElem = document.getElementById(new_id);
    

    //swap contents
    swap(oldElem,newElem);
}

function swap(oldElem,newElem){
    let temp = oldElem;
    oldElem.innerHTML = newElem.innerHTML;
    newElem = temp;
}
function hideError(identifier){
    let error_elem = document.querySelector(identifier);
    error_elem.style.display = "none";
}
function showError(err_statement,identifier){
    let error_elem = document.querySelector(identifier);
    error_elem.style.display = "block";
    error_elem.innerHTML = err_statement;
}

function check_empty_input(input_array,length){

    let status = false;

    for(let i = 0; i < length-1; i++){
        if(input_array[i].value == ''){
            status = true;
            console.log("an input field is empty");
            break;
        }
    }
    return status;

}

function ajaxSubmit(endpoint,callback,data=null){

    request.onreadystatechange = function(){
        if(this.readyState == 4  && this.status == 200){
                response = this.responseText;
                callback();
        }
    }

    request.open("POST",endpoint);
    request.send(data);

}

function redirect_page(url){
    window.location.assign(url);
}

