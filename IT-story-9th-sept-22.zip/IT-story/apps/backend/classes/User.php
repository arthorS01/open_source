
<?php

    require_once "Controller.php";

    
    
    class User extends Controller{

        private $username;
        private $password;
        private $email;
        private $matNo;
        private $account;
        
    
        public function checkUser($username,$password){

            $result = $this->sql("SELECT * FROM users WHERE username ='$username' AND password = '$password'");
            $result = mysqli_fetch_assoc($result);

            if(!$result){
           
                return false;
            }
          
            return true;

       }
    
        public  function createUser(){
            
 
                $result = $this->addUser($this->username,$this->matNo,$this->account,$this->password,$this->email) ;
               
                if(!$result){
                    return false;
                }
                 return true; 
            
        }
        public function get_data($username,$password,$selector){
          
                $result = $this->getUserDetails($username,$password);

                if($result){

                    $result = mysqli_fetch_assoc($result);
                    return $result[$selector];

                }
            return false;
        }

        public function setUser($username,$password,$email,$matNo,$account){
            
         
           $this->username  = $username;
           $this->password  = $password;
           $this->email     = $email;
           $this->matNo     = $matNo;
           $this->account  = $account;
   
        }

        public function email_exist($email){

            $result = $this->check_existing_email($email);
            $result = mysqli_fetch_assoc($result);

            if($result){
                return true;
            }

            return false;
        }

       

        public function get_activities($offset){
            //gets all student activities based on
            // the offset value

            $result = $this->sql("SELECT * FROM activities");
            
        }

        public function add_activity($email , $activity , $picture){

            $result = $this->sql("INSERT INTO activities(email,activity,background_image) VALUES('$email','$activity','$picture')");
            if($result){
                return true;
            }

            return false;
        }

        public function search($value){
            $result = $this->sql("SELECT * FROM users WHERE first_name = '$value' OR last_name = '$value' OR username = '$value' ");
            $output = [];

            if($result){
                
                while($row = mysqli_fetch_assoc($result)){

                    array_push($output,$row);
                }
                return $output;
            }
            return false;
        }

        public function sendMessage($message,$incoming_id,$outgoing_id){
            $result = $this->sql("INSERT INTO messages(incoming_email,outgoing_email,message) VALUES('$incoming_id','$outgoing_id','$message')");
            if($result){
                return true;
            }

            return false;
        }

        public function set($user_id,$setting,$type){

            
            switch($type){

                case 1:
                    $result = $this->sql("UPDATE user_settings SET first_name ='".$setting["first_name"]."',last_name = '".$setting["last_name"]."',company_name = '".$setting["company_name"] ."',
                    company_location = '".$setting["company_location"] ."', employer_name = '".$setting["employer_name"]."' WHERE email ='$user_id'");
                break;
                case 2:
                    $result = $this->sql("UPDATE user_settings SET settings ='$json_data' WHERE email ='$user_id'");
                    break;
                default:
                    echo "<h6>Error updating settings please check your type</h6>";
                    break;
            }

            if($result){

                return true;
            }
            return false;
        }
    
    }

  

    $user = new User();
    //$user->setUser("john","123456","stephenarthor190@gmail.com","cos/2998/2017","supervisor");
   // $user ->createUser();
 