
<?php

    require_once "Controller.php";

    class Validation extends Controller{


       

        public function sanitize($string){

            $string = filter_var($string,FILTER_SANITIZE_STRING);
            $string = trim($string);
            $string = stripslashes($string);
            $string = htmlspecialchars($string);

            return $string;
        }
    
       public function checkPassword($password){
           //check password
            $upperCaseCount = $lowerCaseCount = $specialCount = $numberCount =  0;
            $length = strlen($password);
            $status = false;
            for( $counter = 0; $counter < $length; $counter++){

                    if(ctype_digit($password[$counter])){
                        ++$numberCount;
                    }
                    if(ctype_lower($password[$counter])){
                        ++$lowerCaseCount;
                    }
                    if(ctype_upper($password[$counter])){
                        ++$upperCaseCount;
                    }
                    if(ctype_punct($password[$counter])){
                        ++$specialCount;
                    }
            }
        

            if($numberCount > 0 && $lowerCaseCount > 0 && $specialCount > 0 && $upperCaseCount > 0){
               
               $status =  true;
            }
        
            return $status;
       }
 
       public function check_num_string($str){
           $length = strlen($str);
            $status = false;         //valid

           for($counter = 0; $counter < $length; $counter++){
                if(ctype_digit($str[$counter])){
                    $status = true;
                    break;
                }
           }
           return $status;
       }

    }



    $valid = new Validation ;

    
  
  
  
