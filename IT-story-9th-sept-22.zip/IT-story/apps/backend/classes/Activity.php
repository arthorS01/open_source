<?php


    require_once "Controller.php";
    require_once "Validation.php";


    class Activity extends Controller{

        private $id;
        private $email;
        private $activity;
        private $date;
        private $error;


        public function set_email($email){

            $this->email = $email;
        }
        public function get_error(){
            return $this->error;
        }
        public function getDetails(){

            try{
                $result = $this->sql("SELECT * FROM activities WHERE email = '$this->email' ");
                $all_result = [];
                if(!$result){
                    throw new Exception("something went wrong");
                }else{
                    while($rows = mysqli_fetch_assoc($result)){
                    
                        $date = strtotime($rows["date"]);
                        $date = date("d-m-y",$date);
                        $rows["date"] = $date;
                        
                       array_push($all_result,$rows);  
                    }
                    echo JSON_encode($all_result);
                }
            }catch(Exception $e){
                $this->error = "something went wrong";
                return false;
            }
        }
     
        public function get_pic_dir($src){

           try{ 
            if($dir_files = scandir($src)){

                $filter = [".",".."];

                $result = array_diff($dir_files,$filter);

                return $result;
            }else{
                throw new Exception("Please check the source provided");
            }
        }catch(Exception $e){
            echo"please check the src provided";
        }
    }
    }

    
    $activities = new Activity;
  