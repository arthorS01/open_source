
<?php

    require_once "Db.php";

    class Controller extends Db{


        protected function sql($query){

            $connection =  $this->mysql_connect();

            $result = mysqli_query($connection,$query);

            $this->close_connect();

            return $result;
         }
         protected function addUser($username,$matNO,$accountType,$password,$email){

            $result = $this->sql("INSERT INTO users(username,mat_number,account,password,email) VALUES('$username','$matNO','$accountType','$password','$email')");

            return $result;

         }
         protected function getUserDetails($username,$password){

            $result = $this->sql("SELECT * FROM users WHERE username = '$username' AND password = '$password'");
            return $result;

         }

         protected function check_existing_email($email){

            $result = $this->sql("SELECT email FROM users WHERE email = '$email'");
            return $result;
        }

    }

    $testC = new Controller;
   
  
  
  
