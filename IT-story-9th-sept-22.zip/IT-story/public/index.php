
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../UI/style1.css" rel="stylesheet" type="text/css">
    <title>IT-story</title>
</head>

<body onload="gallary()">

   <div id="body" >

        <section id="captions" ></section>

        <section id="form">

            <span>forgot password?</span>

            <img src="../assets/user (1).png" height="100" width="100">

            <div>
                <form name="myform" class="form" >
                    <p class="error">error</p>

                    <input type="text" name="username" placeholder="Username" onkeyup="hideError('.error')">
                    <br>
                    <input type="password" name="password" placeholder="password" onkeyup="hideError('.error')">
                    <br>
                    <input type="submit"    value="Log-in" name="submit_button" onclick="submitForm('../apps/backend/userApps/processLogin.php',processForm)">
                    
                    <p>Dont have an account?</p>
                    <button type="button" onclick="bring_page('#form','../apps/backend/userApps/create_account.php')">Get Started</button>
                </form>
              
        </div>
        </section>
   </div>



</body>

<script src="../apps/backend/libraries/login.js"></script>
<script src="../UI/javascript/index.js"></script>
</html>
